#include <stdio.h>
#include <stdlib.h>

int main() {
    FILE *fp;
    char buffer[100];

    fp = fopen("data.txt", "w+"); // "w+" creates the file if it doesn't exist and allows reading & writing
    if (fp == NULL) {
        perror("Error opening file");
        return 1;
    }

    const char *text = "Hello, File Handling in C!";
    fputs(text, fp);

    rewind(fp);

    if (fgets(buffer, sizeof(buffer), fp) != NULL) {
        printf("Contents of the file:\n%s\n", buffer);
    } else {
        printf("Failed to read from the file.\n");
    }

    fclose(fp);

    return 0;
}

